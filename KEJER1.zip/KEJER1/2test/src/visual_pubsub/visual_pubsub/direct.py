import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from geometry_msgs.msg import Point
from sensor_msgs.msg import JointState
import numpy as np

class CinematicaDirecta(Node):

    def __init__(self):
        super().__init__('cinematica_directa')

        # Suscribe a valores articulares
        self.subscriber = self.create_subscription(
            Float64MultiArray,
            'joint_values',
            self.callback,
            10
        )

        # Publica la posición del efector
        self.publisher = self.create_publisher(
            Point,
            'end_effector_position',
            10
        )

        # Publica JointState para que el robot se mueva en RViz
        self.joint_pub = self.create_publisher(
            JointState,
            'joint_states',
            10
        )

        # Longitudes del robot (ajústalas a tu URDF/DH real)
        self.l1 = -1.0
        self.l2 = 0.2
        self.l3 = 1.0
        self.l4 = 0.15

    def callback(self, msg):
        q = msg.data
        if len(q) < 4:
            self.get_logger().warn("Se requieren al menos 4 valores articulares.")
            return

        q1, q2, q3, q4 = q[:4]

        # Longitud efectiva del último eslabón
        L = self.l3 + self.l4

        # Fórmulas de CD (ajusta si tu robot es distinto)
        x = L * np.sin(q1) * np.sin(q3) + L * np.cos(q1) * np.cos(q2) * np.cos(q3) + self.l2 * np.cos(q1) * np.cos(q2)
        y = L * np.sin(q1) * np.cos(q2) * np.cos(q3) + self.l2 * np.sin(q1) * np.cos(q2) - L * np.sin(q3) * np.cos(q1)
        z = L * np.sin(q2) * np.cos(q3) + self.l2 * np.sin(q2) + self.l1

        # Publicar posición como Point
        p = Point()
        p.x = float(x)
        p.y = float(y)
        p.z = float(z)
        self.publisher.publish(p)

        # Publicar valores articulares como JointState
        joint_msg = JointState()
        joint_msg.header.stamp = self.get_clock().now().to_msg()
        joint_msg.name = ['q1', 'q2', 'q3', 'q4']
        joint_msg.position = [q1, q2, q3, q4]
        self.joint_pub.publish(joint_msg)

        # Consola
        self.get_logger().info(f"CD → Posición: x={x:.3f}, y={y:.3f}, z={z:.3f}")

def main(args=None):
    rclpy.init(args=args)
    node = CinematicaDirecta()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
