All images, must be square in some 2^x number, to a maximum of 512x512 (2^9)
The images should have depth 3 (RGB) or 4 (RGBA)

