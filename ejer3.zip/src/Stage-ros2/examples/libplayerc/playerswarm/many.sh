#!/bin/bash
./single -i 0 &
./single -i 1 &
./single -i 2 &
./single -i 3 &
./single -i 4 &
