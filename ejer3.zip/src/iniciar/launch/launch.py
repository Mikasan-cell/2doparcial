from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
import os

from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # Ruta al archivo .world dentro del paquete mi_mundo_stage
    world_path = os.path.join(
        get_package_share_directory('mi_mundo_stage'),
        'worlds/laberinto.world'
    )

    return LaunchDescription([
        DeclareLaunchArgument(
            'world', default_value=world_path,
            description='Archivo del mundo para la simulación'
        ),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(
                    get_package_share_directory('stage_ros2'),
                    'launch/stage_ros2_launch.py'
                )
            ),
            launch_arguments={'world': world_path}.items()
        ),
    ])

